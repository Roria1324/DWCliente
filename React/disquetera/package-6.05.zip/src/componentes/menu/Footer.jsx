import React from "react";
import "./Footer.css"

const Footer = () => {
    return (
        <>
        <footer className="footer">
            <span>
                @ 2025 Mi "Disquetera" oficial :).
            </span>
        </footer>
        </>
    )
}

export default Footer;