"use strict";
import React from 'react'

const EditarDisco = () => {
  return (
    <div>EditarDisco</div>
  )
}

export default EditarDisco