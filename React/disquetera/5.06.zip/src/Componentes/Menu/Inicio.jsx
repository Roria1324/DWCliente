"use strict";
import React from 'react'

const Inicio = () => {
  return (
    <>
      <div className='containerIncio'>
        <h2 className='presentacion'>Inicio</h2>
        <p className='texto'>Bienvenido a tu disquetera.</p>
      </div>
    </>
  )
}

export default Inicio