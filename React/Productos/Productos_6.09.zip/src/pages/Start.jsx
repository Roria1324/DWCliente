import React from 'react'
import "./Start.css"

const Start = () => {
  return (
    <div>Home</div>
  )
}

export default Start