import React from 'react'

const Products = () => {
  return (
    <div>Coming soon :)</div>
  )
}

export default Products