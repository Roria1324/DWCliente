import React from 'react'
import "./Start.css"

const Start = () => {
  return (
    <div>Start</div>
  )
}

export default Start