"use strict";
import React, { createContext, useState } from "react";
import { supabaseConexion } from "../hooks/supabase";

const contextProducts = createContext();

const ProductsProvider = ({ children }) => {
  const [errorProducts, setErrorProducts] = useState("");
  const [dataProducts, setDataProducts] = useState([]);

  const getTable = async () => {
    try {
      const { data, error } = await supabaseConexion
        .from("productos")
        .select("*");

      if (error) throw error;

      setDataProducts(data);
      setErrorProducts("");
    } catch (error) {
      setErrorProducts(error.message);
    }
  };

  const getProductsOrdered = async (field, order) => {
    try {
      const { data, error } = await supabaseConexion
        .from("productos")
        .select("*")
        .order(field, { ascending: order === "asc" });

      if (error) throw error;

      setDataProducts(data);
      setErrorProducts("");
    } catch (error) {
      setErrorProducts(error.message);
    }
  };

  const getProductsByName = async (search, field, order) => {
    try {
      const { data, error } = await supabaseConexion
        .from("productos")
        .select("*")
        .ilike("name", `%${search}%`)
        .order(field, { ascending: order === "asc" });

      if (error) throw error;

      setDataProducts(data);
      setErrorProducts("");
    } catch (error) {
      setErrorProducts(error.message);
    }
  };

  const getProductsByPrice = async (minPrice, maxPrice) => {
    try {
      let query = supabaseConexion.from("productos").select("*");

      if (minPrice !== "") {
        query = query.gte("price", minPrice);
      }

      if (maxPrice !== "") {
        query = query.lte("price", maxPrice);
      }

      const { data, error } = await query;

      if (error) throw error;

      setDataProducts(data);
      setErrorProducts("");
    } catch (error) {
      setErrorProducts(error.message);
    }
  };

  const elements = {
    getTable,
    getProductsOrdered,
    getProductsByName,
    getProductsByPrice,
    dataProducts,
    errorProducts,
  };

  return (
    <contextProducts.Provider value={elements}>
      {children}
    </contextProducts.Provider>
  );
};

export default ProductsProvider;
export { contextProducts };
