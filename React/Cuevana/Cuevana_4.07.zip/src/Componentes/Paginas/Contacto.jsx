"use strict"
import "./EstiloPaginas.css"

const Contacto = () => {

    return (
        <>
            <div class="container">
                <p class="text">Contacto</p>
            </div>
        </>
    )
}

export default Contacto