import React from 'react'

const GaleriaFiltrada = () => {
  return (
    <div>GaleriaFiltrada</div>
  )
}


export default GaleriaFiltrada