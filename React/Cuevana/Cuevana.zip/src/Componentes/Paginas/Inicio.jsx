"use strict"
import React from "react";
import "./EstiloPaginas.css"

const Inicio = () => {
    return (
        <>
         
            <div class="container">
                <p class="text">INICIO</p>
            </div>
        
        </>
    )
}

export default Inicio;