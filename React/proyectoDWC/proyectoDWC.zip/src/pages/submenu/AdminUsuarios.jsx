import React from "react";

const AdminUsuarios = () => {
  return (
    <>
      <h2>Administración de usuarios/as.</h2>
    </>
  );
};

export default AdminUsuarios;
