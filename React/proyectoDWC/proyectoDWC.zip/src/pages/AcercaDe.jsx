import React from "react";

const AcercaDe = () => {
  return (
    <>
      <h2>Este es la información de los desarrolladores.</h2>
    </>
  );
};

export default AcercaDe;
