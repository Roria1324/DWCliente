import React from "react";

const Error = () => {
  return (
    <>
      <h1>¡Ups! Se ha producido un error. Por favor vuelva a intentarlo.</h1>
    </>
  );
};

export default Error;
