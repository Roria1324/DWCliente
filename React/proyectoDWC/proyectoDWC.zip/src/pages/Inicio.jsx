import React from "react";

const Inicio = () => {
  return (
    <>
      <h2>Este es el componente de Inicio.</h2>
    </>
  );
};

export default Inicio;
