import React from "react";

const Planetas = () => {
  return <div>Planetas</div>;
};

export default Planetas;
