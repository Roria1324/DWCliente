import React, { useState } from "react";
import { traerDatos } from "../libraries/traerDatos";

/************ Cear un contexto global
 * Dará acceso a un conjunto de componentes (children) a todo
 * lo contenido en el contexto ya sean variables, estados o funciones.
 *
 * Será necesario hacer tres cosas:
 *    ->  crear el contexto con la función createContext y dotarlo de contenido a compartir,
 *    ->  crea un proveedor (componente) que se encargará de compartir la información y
 *    ->  utilizar useContext para usar el contexto en aquellos componentes que lo necesiten.
 *
 */

/** Se crea el contexto con el método createContext()
 * Es necesario que sea de ámbito global, por lo que debe declararse fuera del componente.
 */
const contextoPlanetas = createContext();

const PlanetasContexto = ({ children }) => {
  /** Estado al que accederán los componentes dentro del contexto. */
  const [planetas, setPlanetas] = useState([]);
  const [residentes, setResidentes] = useState([]);

  /** URL de los planetas  */
  const urlPlanetas = "https://swapi.py4e.com/api/planets";

  // Función para obtener el listado de planetas.
  const taerPlanetas = async () => {
    try {
      const planetasDatos = await traerDatos();
      setPlanetas(planetasDatos);
    } catch (error) {
      // Se gestiona el error de froma adecuada.
      throw error; //No es la mejor manera (hay que informar al usuario).
    }
  };

  // Función para obtener los residentes de un planeta.
  const traerResidentes = async (residentes) => {
    try {
      const promesasResidentes = residentes.map((residente) => {
        return traerDatos(residente);
      });
      const datosResidentes = await Promise.allSettled(promesasResidentes);
      setResidentes(datosResidentes);
    } catch (error) {
      throw error; // No es la mejor manera (hay que informar al usuario).
    }
  };

  return <div>PlanetasContexto</div>;
};

export default PlanetasContexto;
