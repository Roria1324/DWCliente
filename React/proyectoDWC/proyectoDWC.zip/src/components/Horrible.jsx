import React from "react";

const Horrible = () => {
  return <div>HolaHorrible</div>;
};

export default Horrible;
