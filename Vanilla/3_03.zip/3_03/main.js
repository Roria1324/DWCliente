"use strict";

import { createCourse } from "./biblioteca/ejercicio1.js";
import { createCourseNew } from "./biblioteca/ejercicio2.js";
import { discente } from "./biblioteca/ejercicio3.js";
import { createCourseMatricula } from "./biblioteca/ejercicio4.js";
import { showObject } from "./biblioteca/ejercicio5.js"

//Ejercicio 1
console.log(createCourse);

//Ejercio 2
//createCourseNew('2º_DAW', 2025, 'necesito una cerveza');

//Ejercicio 3
//console.log(discente.averageMarks());
//console.log(discente.showIinfoDiscente());
//console.log(discente.showReport());

//Ejercicio 4
//console.log(createCourseMatricula("JS", 20, "hola").matricular(discente));

//Ejercicio 5
showObject(discente);